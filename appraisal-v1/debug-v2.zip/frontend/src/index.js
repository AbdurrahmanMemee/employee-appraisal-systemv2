// src/index.js
import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App from './App';

// Global error logging - catches crashes outside React tree
window.onerror = function(msg, src, line, col, err) {
  console.error('GLOBAL ERROR:', msg, 'at', src, line+':'+col);
  document.getElementById('root').innerHTML =
    '<div style="padding:2rem;font-family:monospace;background:#fff1f0;min-height:100vh">' +
    '<h2 style="color:#c00">Global JS Error</h2>' +
    '<p><strong>Message:</strong> ' + msg + '</p>' +
    '<p><strong>Source:</strong> ' + src + ' line ' + line + '</p>' +
    '<p><strong>Error:</strong> ' + (err ? err.stack : 'none') + '</p>' +
    '</div>';
};

window.addEventListener('unhandledrejection', function(e) {
  console.error('UNHANDLED PROMISE REJECTION:', e.reason);
  document.getElementById('root').innerHTML =
    '<div style="padding:2rem;font-family:monospace;background:#fff1f0;min-height:100vh">' +
    '<h2 style="color:#c00">Unhandled Promise Rejection</h2>' +
    '<p><strong>Reason:</strong> ' + (e.reason ? (e.reason.stack || e.reason.message || e.reason) : 'unknown') + '</p>' +
    '</div>';
});

try {
  const root = ReactDOM.createRoot(document.getElementById('root'));
  root.render(
    <React.StrictMode>
      <App />
    </React.StrictMode>
  );
} catch(e) {
  console.error('ROOT RENDER CRASH:', e);
  document.getElementById('root').innerHTML =
    '<div style="padding:2rem;font-family:monospace;background:#fff1f0;min-height:100vh">' +
    '<h2 style="color:#c00">Root Render Crash</h2>' +
    '<p>' + (e.stack || e.message) + '</p>' +
    '</div>';
}
