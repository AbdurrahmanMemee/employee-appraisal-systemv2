// components/Dashboard.js - Updated with Zustand
import React from 'react';
import { Users, CalendarDays, AlertCircle, ClipboardList, Plus } from 'lucide-react';
import { useUIActions, useComputed, useMeetings, useScheduledAppraisals } from '../store/useAppStore';

const Dashboard = () => {
  // Get data and actions from Zustand store
  const uiActions = useUIActions();
  const computed = useComputed();
  const meetings = useMeetings();
  const scheduledAppraisals = useScheduledAppraisals();

  // Get dashboard statistics
  const stats = computed.getDashboardStats();

  const getEmployeeName = (empNumber) => {
    const emp = computed.getEmployeeById(empNumber);
    return emp ? `${emp.employee_name} ${emp.employee_surname}` : 'Unknown';
  };

  return (
    <div className="space-y-6">
      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-white rounded-lg shadow p-6 border-l-4 border-blue-500">
          <div className="flex items-center">
            <Users className="w-8 h-8 text-blue-500" />
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Total Employees</p>
              <p className="text-2xl font-bold text-gray-900">{stats.totalEmployees}</p>
            </div>
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow p-6 border-l-4 border-green-500">
          <div className="flex items-center">
            <CalendarDays className="w-8 h-8 text-green-500" />
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Scheduled Appraisals</p>
              <p className="text-2xl font-bold text-gray-900">{stats.scheduledAppraisals}</p>
            </div>
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow p-6 border-l-4 border-red-500">
          <div className="flex items-center">
            <AlertCircle className="w-8 h-8 text-red-500" />
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Overdue Appraisals</p>
              <p className="text-2xl font-bold text-gray-900">{stats.overdueAppraisals}</p>
            </div>
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow p-6 border-l-4 border-purple-500">
          <div className="flex items-center">
            <ClipboardList className="w-8 h-8 text-purple-500" />
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Recent Meetings</p>
              <p className="text-2xl font-bold text-gray-900">{stats.recentMeetings}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Quick Actions */}
      <div className="bg-white rounded-lg shadow p-6">
        <h3 className="text-lg font-medium text-gray-900 mb-4">Quick Actions</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <button 
            onClick={() => uiActions.setShowNewForm('meeting')}
            className="flex items-center p-4 bg-blue-50 rounded-lg hover:bg-blue-100 transition-colors"
          >
            <Plus className="w-5 h-5 text-blue-600 mr-3" />
            <span className="text-blue-600 font-medium">New Meeting</span>
          </button>
          <button 
            onClick={() => uiActions.setShowNewForm('appraisal')}
            className="flex items-center p-4 bg-green-50 rounded-lg hover:bg-green-100 transition-colors"
          >
            <Plus className="w-5 h-5 text-green-600 mr-3" />
            <span className="text-green-600 font-medium">Schedule Appraisal</span>
          </button>
          <button 
            onClick={() => uiActions.setShowNewForm('incident')}
            className="flex items-center p-4 bg-purple-50 rounded-lg hover:bg-purple-100 transition-colors"
          >
            <Plus className="w-5 h-5 text-purple-600 mr-3" />
            <span className="text-purple-600 font-medium">Log Incident</span>
          </button>
        </div>
      </div>

      {/* Recent Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-lg shadow">
          <div className="px-6 py-4 border-b border-gray-200">
            <h3 className="text-lg font-medium text-gray-900">Upcoming Appraisals</h3>
          </div>
          <div className="p-6">
            {scheduledAppraisals.slice(0, 5).map((scheduled) => (
              <div key={scheduled.schedule_id} className="flex items-center justify-between py-3 border-b last:border-b-0">
                <div>
                  <p className="font-medium text-gray-900">{getEmployeeName(scheduled.employee_number)}</p>
                  <p className="text-sm text-gray-500">{scheduled.scheduled_date}</p>
                </div>
                <span className="text-sm text-blue-600">{scheduled.status}</span>
              </div>
            ))}
            {scheduledAppraisals.length === 0 && (
              <div className="text-center py-4 text-gray-500">
                No upcoming appraisals scheduled
              </div>
            )}
          </div>
        </div>

        <div className="bg-white rounded-lg shadow">
          <div className="px-6 py-4 border-b border-gray-200">
            <h3 className="text-lg font-medium text-gray-900">Recent Meetings</h3>
          </div>
          <div className="p-6">
            {meetings.slice(0, 5).map((meeting) => (
              <div key={meeting.meet_id} className="flex items-center justify-between py-3 border-b last:border-b-0">
                <div>
                  <p className="font-medium text-gray-900">{getEmployeeName(meeting.employee_number)}</p>
                  <p className="text-sm text-gray-500">{meeting.meeting_type} - {meeting.meeting_date}</p>
                </div>
                <button 
                  onClick={() => uiActions.setSelectedMeeting(meeting)}
                  className="text-sm text-blue-600 hover:text-blue-800"
                >
                  View
                </button>
              </div>
            ))}
            {meetings.length === 0 && (
              <div className="text-center py-4 text-gray-500">
                No recent meetings recorded
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Performance Overview */}
      <div className="bg-white rounded-lg shadow p-6">
        <h3 className="text-lg font-medium text-gray-900 mb-4">Performance Overview</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="text-center">
            <div className="text-3xl font-bold text-green-600">
              {computed.getFilteredEmployees().filter(emp => emp.average_employee_rating >= 4).length}
            </div>
            <div className="text-sm text-gray-600 mt-1">High Performers (4+ rating)</div>
          </div>
          <div className="text-center">
            <div className="text-3xl font-bold text-yellow-600">
              {computed.getFilteredEmployees().filter(emp => emp.average_employee_rating >= 3 && emp.average_employee_rating < 4).length}
            </div>
            <div className="text-sm text-gray-600 mt-1">Average Performers (3-4 rating)</div>
          </div>
          <div className="text-center">
            <div className="text-3xl font-bold text-red-600">
              {computed.getFilteredEmployees().filter(emp => emp.average_employee_rating > 0 && emp.average_employee_rating < 3).length}
            </div>
            <div className="text-sm text-gray-600 mt-1">Needs Improvement (&lt; 3 rating)</div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;